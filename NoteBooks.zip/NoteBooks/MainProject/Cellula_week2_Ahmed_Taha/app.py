import streamlit as st
from PIL import Image

from classifier import classify_text, load_classifier
from database import add_record, clear_db, read_all
from imagecaption import generate_caption, load_model

st.set_page_config(page_title="Toxic Content Classifier", layout="wide")


@st.cache_resource
def get_models():
    load_model()
    load_classifier()
    return True


def show_result(label, confidence):
    if label == "toxic":
        st.error(f"Toxic ({confidence:.1%})")
    else:
        st.success(f"Non-toxic ({confidence:.1%})")


get_models()

st.title("Toxic Content Classification")
page = st.sidebar.radio("Menu", ["Text", "Image", "Database"])

if page == "Text":
    text = st.text_area("Enter text", height=150)
    if st.button("Classify"):
        if text.strip():
            label, confidence = classify_text(text)
            add_record("text", text.strip(), label, confidence)
            show_result(label, confidence)
        else:
            st.warning("Please enter some text.")

elif page == "Image":
    uploaded = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png", "webp"])
    if uploaded is not None:
        image = Image.open(uploaded)
        st.image(image, width=400)
        if st.button("Caption and classify"):
            with st.spinner("Processing"):
                caption = generate_caption(image)
                label, confidence = classify_text(caption)
            add_record("image_caption", caption, label, confidence)
            st.write(f"Caption: {caption}")
            show_result(label, confidence)

else:
    data = read_all()
    st.write(f"{len(data)} records")
    st.dataframe(data, use_container_width=True)
    col1, col2 = st.columns(2)
    with col1:
        st.download_button(
            "Download CSV", data.to_csv(index=False), "database.csv", "text/csv"
        )
    with col2:
        if st.button("Clear database"):
            clear_db()
            st.rerun()
