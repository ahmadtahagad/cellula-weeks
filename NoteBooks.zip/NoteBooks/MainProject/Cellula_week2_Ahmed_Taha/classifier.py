import os
import torch
from peft import PeftModel, PeftConfig
from transformers import AutoModelForSequenceClassification, AutoTokenizer

ADAPTER_DIR = os.path.join(os.path.dirname(__file__), "toxic_distilbert_lora")
device = "cuda" if torch.cuda.is_available() else "cpu"

_tokenizer = None
_model = None


def load_classifier():
    global _tokenizer, _model
    if _model is None:
        config = PeftConfig.from_pretrained(ADAPTER_DIR)
        base = AutoModelForSequenceClassification.from_pretrained(
            config.base_model_name_or_path,
            num_labels=2,
            id2label={0: "non-toxic", 1: "toxic"},
            label2id={"non-toxic": 0, "toxic": 1},
        )
        peft_model = PeftModel.from_pretrained(base, ADAPTER_DIR)
        _model = peft_model.merge_and_unload().to(device)
        _model.eval()
        _tokenizer = AutoTokenizer.from_pretrained(ADAPTER_DIR)
    return _tokenizer, _model


def classify_text(text):
    tokenizer, model = load_classifier()
    inputs = tokenizer(
        text, return_tensors="pt", truncation=True, max_length=128
    ).to(device)
    with torch.no_grad():
        logits = model(**inputs).logits
    probs = torch.softmax(logits, dim=-1)[0]
    idx = int(torch.argmax(probs))
    return model.config.id2label[idx], float(probs[idx])
