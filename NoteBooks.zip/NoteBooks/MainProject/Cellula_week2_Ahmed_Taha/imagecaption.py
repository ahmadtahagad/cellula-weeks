import torch
from PIL import Image
from transformers import BlipProcessor, BlipForConditionalGeneration

MODEL_NAME = "Salesforce/blip-image-captioning-base"
device = "cuda" if torch.cuda.is_available() else "cpu"

_processor = None
_model = None


def load_model():
    global _processor, _model
    if _model is None:
        _processor = BlipProcessor.from_pretrained(MODEL_NAME)
        _model = BlipForConditionalGeneration.from_pretrained(MODEL_NAME).to(device)
        _model.eval()
    return _processor, _model


def generate_caption(image, max_new_tokens=40):
    processor, model = load_model()
    if not isinstance(image, Image.Image):
        image = Image.open(image)
    image = image.convert("RGB")
    inputs = processor(images=image, return_tensors="pt").to(device)
    with torch.no_grad():
        output = model.generate(**inputs, max_new_tokens=max_new_tokens, num_beams=3)
    return processor.decode(output[0], skip_special_tokens=True).strip()
