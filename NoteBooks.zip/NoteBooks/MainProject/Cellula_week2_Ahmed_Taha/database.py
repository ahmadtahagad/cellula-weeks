import os
from datetime import datetime
import pandas as pd

DB_PATH = os.path.join(os.path.dirname(__file__), "database.csv")
COLUMNS = ["timestamp", "source", "content", "classification", "confidence"]


def init_db():
    if not os.path.exists(DB_PATH):
        pd.DataFrame(columns=COLUMNS).to_csv(DB_PATH, index=False)


def add_record(source, content, classification, confidence):
    init_db()
    row = pd.DataFrame(
        [
            {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "source": source,
                "content": content,
                "classification": classification,
                "confidence": round(confidence, 4),
            }
        ]
    )
    row.to_csv(DB_PATH, mode="a", header=False, index=False)


def read_all():
    init_db()
    return pd.read_csv(DB_PATH)


def clear_db():
    pd.DataFrame(columns=COLUMNS).to_csv(DB_PATH, index=False)
