# Intelligent AI Coding Assistant (Cellula NLP Internship – Project 2)

A Streamlit chatbot that **classifies** each request, **routes** it, uses **Chroma RAG** for code generation,
**checks relevance** of retrieved knowledge, **learns from user feedback**, remembers the conversation, and
runs generated code through a separate **Code Runner tool**.

```
User → LLM Intent Classifier ─┬─ EXPLAIN  → LLM (no RAG / no embeddings / no vector search) → Answer
                              └─ GENERATE → Chroma top-k → LLM Relevance Evaluator ─┬─ Relevant → LLM codegen → Answer → [▶ Run] Code Runner
                                                                                    └─ Not relevant → "Can you teach me?" → user solution
                                                                                                        → embed + metadata → Chroma
```

## Requirement → implementation map

| Requirement | Where |
|---|---|
| 1. Streamlit UI: chat, history, file upload, streaming, highlighted code, Run button, memory view | `app.py` |
| 2. LLM-based intent classifier (Explain / Generate) | `assistant/classifier.py` |
| 3. Router; Route 1 has **no** RAG, Route 2 uses RAG + relevance | `assistant/pipeline.py` (`_explain`, `_generate`) |
| 4. RAG: chunking, embeddings, similarity search, top-k | `assistant/rag.py` |
| 5. Chroma store with documents, embeddings, metadata, source | `KnowledgeBase` in `assistant/rag.py` |
| 6. Relevance check by a second LLM (Relevant / Not Relevant) | `assistant/relevance.py` |
| 7. Human-feedback learning → embed → store in Chroma | `KnowledgeBase.learn_from_user`, `pipeline.handle` |
| 8. Long-term memory (questions, code, language/framework prefs, follow-ups) | `assistant/memory.py` (persisted to `data/memory.json`) |
| 9. Code generation (complete code, comments, best practices, error handling, Markdown) | `GENERATE_SYSTEM` prompt |
| 10. Code Runner tool (string in → stdout/stderr/result out; LLM never executes) | `assistant/code_runner.py` |

## Run it

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                  # add your LLM_API_KEY
python seed_knowledge.py                              # optional: starter knowledge (or click the sidebar button)
streamlit run app.py
```

Any OpenAI-compatible provider works (OpenAI, Groq, Ollama…) through `LLM_BASE_URL`.
Embeddings use Chroma's default local MiniLM model (downloaded on first use) so no embedding API key is needed.

## Try this demo script

1. `Explain this code: def f(n): return n if n<2 else f(n-1)+f(n-2)` → green "Route 1" badge, no retrieved context.
2. `Build a Flask API` → Route 2, relevant context shown in the expander, code appears with **▶ Run**.
3. `Write a quantum annealing optimizer in Python` → relevance fails, assistant asks you to teach it.
4. Paste a code solution in a fenced block → it is embedded and stored; repeat step 3 and it is now answered from your solution.
5. Say `I prefer Python and FastAPI`, then `now make it async` → check the Memory panel.

## Tests

`pytest -q tests` – offline (fake LLM + fake embeddings): routing, no-RAG guarantee, relevance failure,
feedback learning, memory persistence, chunking, and the runner (success / error / timeout).

## Notes

* The Code Runner uses a subprocess with a timeout, isolated Python mode, scrubbed env and resource limits.
  That is process isolation, not a hardened sandbox – use a container for untrusted multi-user hosting.
* Feedback learning triggers only when the previous answer was "not relevant" **and** the next message
  contains a code solution; otherwise the message is handled as a normal request.
