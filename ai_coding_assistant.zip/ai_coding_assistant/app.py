"""Streamlit UI for the Intelligent AI Coding Assistant.

Run:  streamlit run app.py
"""
import os

import streamlit as st

from assistant import config
from assistant.code_runner import run_code
from assistant.llm import LLM
from assistant.memory import ConversationMemory
from assistant.pipeline import AssistantPipeline, extract_code_blocks
from assistant.rag import KnowledgeBase

st.set_page_config(page_title="AI Coding Assistant", page_icon="💻", layout="wide")

ROUTE_BADGES = {
    "explain": "🟢 Route 1 · Code Explanation (no RAG)",
    "generate": "🟡 Route 2 · Code Generation (RAG ✓ relevant)",
    "no_knowledge": "🔴 Route 2 · RAG ✗ not relevant → asked you to teach me",
    "learn": "🟣 Learned from your feedback → stored in Chroma",
}
RUNNABLE = {"python", "py", "python3"}


@st.cache_resource(show_spinner="Loading vector database…")
def get_kb() -> KnowledgeBase:
    return KnowledgeBase()


def init_state():
    ss = st.session_state
    ss.setdefault("messages", [])   # {"role","content","route","sources","runs":{idx: result}}
    ss.setdefault("pipeline", None)
    ss.setdefault("pipeline_key", None)


def build_pipeline(api_key: str, model: str, base_url: str):
    key = (api_key, model, base_url)
    if st.session_state.pipeline is not None and st.session_state.pipeline_key == key:
        return st.session_state.pipeline
    llm = LLM(model=model or None, api_key=api_key or None, base_url=base_url or None)
    old = st.session_state.pipeline
    memory = old.memory if old else ConversationMemory()
    st.session_state.pipeline = AssistantPipeline(llm, get_kb(), memory)
    st.session_state.pipeline_key = key
    return st.session_state.pipeline


def render_message(i: int, msg: dict):
    with st.chat_message(msg["role"]):
        if msg.get("route"):
            st.caption(ROUTE_BADGES.get(msg["route"], msg["route"]))
        st.markdown(msg["content"])  # fenced blocks get syntax highlighting + copy button
        if msg["role"] != "assistant":
            return
        for j, (lang, code) in enumerate(extract_code_blocks(msg["content"])):
            if lang not in RUNNABLE:
                continue
            key = f"{i}-{j}"
            if st.button(f"▶ Run code block {j + 1}", key=f"run-{key}"):
                with st.spinner("Running in Code Runner tool…"):
                    msg.setdefault("runs", {})[key] = run_code(code, "python").to_dict()
            res = msg.get("runs", {}).get(key)
            if res:
                status = "✅ success" if res["ok"] else ("⏱ timed out" if res["timed_out"] else f"❌ exit code {res['returncode']}")
                st.markdown(f"**Execution result** — {status} · {res['duration_s']:.2f}s")
                if res["stdout"]:
                    st.code(res["stdout"], language="text")
                if res["stderr"]:
                    st.code(res["stderr"], language="text")
        if msg.get("sources"):
            with st.expander(f"📚 Retrieved context ({len(msg['sources'])})"):
                for s in msg["sources"]:
                    st.markdown(f"**{s['source']}** · distance `{s['distance']:.3f}`")
                    st.code(s["text"][:700], language="markdown")


def sidebar():
    with st.sidebar:
        st.header("⚙️ Settings")
        api_key = st.text_input("LLM API key", value=config.LLM_API_KEY, type="password")
        model = st.text_input("Model", value=config.LLM_MODEL)
        base_url = st.text_input("Base URL (optional)", value=config.LLM_BASE_URL or "",
                                 help="Any OpenAI-compatible endpoint, e.g. Groq or Ollama.")
        st.divider()

        kb = get_kb()
        st.subheader("📚 Knowledge base (Chroma)")
        st.metric("Stored chunks", kb.count())
        if st.button("Load starter knowledge"):
            from seed_knowledge import seed
            st.success(f"Added {seed(kb)} chunks")
            st.rerun()

        up = st.file_uploader("Upload a file (code or doc)", type=["py", "js", "ts", "java", "cpp", "c", "go", "rs", "txt", "md", "json"])
        uploaded_text = None
        if up is not None:
            uploaded_text = up.getvalue().decode("utf-8", errors="replace")
            st.caption(f"{up.name} · {len(uploaded_text)} chars — attached to your next message.")
            if st.button("➕ Add this file to knowledge base"):
                n = kb.add_document(uploaded_text, source=up.name, extra_metadata={"type": "uploaded_file"})
                st.success(f"Stored {n} chunks")
                st.rerun()
        st.divider()

        with st.expander("🧠 Memory visualization"):
            pipe = st.session_state.pipeline
            if pipe:
                st.json(pipe.memory.snapshot())
            else:
                st.caption("Starts after your first message.")
        if st.button("🗑 Clear chat & memory"):
            if st.session_state.pipeline:
                st.session_state.pipeline.memory.clear()
                st.session_state.pipeline.pending_question = None
            st.session_state.messages = []
            st.rerun()
    return api_key, model, base_url, uploaded_text


def main():
    init_state()
    st.title("💻 Intelligent AI Coding Assistant")
    st.caption("Classifier → Router → Explain (no RAG) | Generate (Chroma RAG → relevance check → LLM) → Code Runner")
    api_key, model, base_url, uploaded_text = sidebar()

    for i, m in enumerate(st.session_state.messages):
        render_message(i, m)

    prompt = st.chat_input("Ask me to explain code, or to write some…")
    if not prompt:
        return
    if not (api_key or base_url):
        st.error("Enter an LLM API key (or a base URL for a local model) in the sidebar.")
        return

    st.session_state.messages.append({"role": "user", "content": prompt + (f"\n\n📎 *attached file ({len(uploaded_text)} chars)*" if uploaded_text else "")})
    with st.chat_message("user"):
        st.markdown(st.session_state.messages[-1]["content"])

    try:
        pipe = build_pipeline(api_key, model, base_url)
        with st.chat_message("assistant"):
            with st.spinner("Classifying and routing…"):
                result = pipe.handle(prompt, uploaded_text=uploaded_text)
            st.caption(ROUTE_BADGES.get(result.route, result.route))
            text = st.write_stream(result.stream)  # response streaming
    except Exception as e:
        st.error(f"Error: {e}")
        return

    st.session_state.messages.append({
        "role": "assistant",
        "content": text,
        "route": result.route,
        "sources": [{"source": d.source, "distance": d.distance, "text": d.text} for d in result.retrieved],
    })
    st.rerun()  # re-render so "Run" buttons appear under code blocks


main()
