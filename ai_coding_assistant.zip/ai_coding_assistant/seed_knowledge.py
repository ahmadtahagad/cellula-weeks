"""Seed the Chroma vector DB with starter programming knowledge.

Usage:
    python seed_knowledge.py                 # built-in starter docs
    python seed_knowledge.py path/to/docs    # also ingest *.md, *.txt, *.py files from a folder
"""
import sys
from pathlib import Path

from assistant.rag import KnowledgeBase

DOCS = {
    "python-sorting": """# Sorting algorithms in Python
Python's built-in `sorted()` and `list.sort()` use Timsort: O(n log n) worst case, O(n) on nearly-sorted data, stable.
Custom ordering: `sorted(items, key=lambda x: x["age"], reverse=True)`.

```python
def quicksort(arr: list) -> list:
    \"\"\"Return a new sorted list (average O(n log n)).\"\"\"
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    mid = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quicksort(left) + mid + quicksort(right)

def merge_sort(arr: list) -> list:
    if len(arr) <= 1:
        return arr
    m = len(arr) // 2
    l, r = merge_sort(arr[:m]), merge_sort(arr[m:])
    out, i, j = [], 0, 0
    while i < len(l) and j < len(r):
        if l[i] <= r[j]:
            out.append(l[i]); i += 1
        else:
            out.append(r[j]); j += 1
    return out + l[i:] + r[j:]
```
Bubble sort and insertion sort are O(n^2); use them only for teaching or tiny inputs. Validate input types and handle empty lists.""",

    "flask-api": """# Building a REST API with Flask
Install: `pip install flask`. Use `jsonify`, `request.get_json()`, proper status codes and error handlers.

```python
from flask import Flask, jsonify, request, abort

app = Flask(__name__)
items = {}          # in-memory store: id -> dict
next_id = 1

@app.get("/items")
def list_items():
    return jsonify(list(items.values()))

@app.post("/items")
def create_item():
    global next_id
    data = request.get_json(silent=True)
    if not data or "name" not in data:
        abort(400, description="'name' is required")
    item = {"id": next_id, "name": data["name"]}
    items[next_id] = item
    next_id += 1
    return jsonify(item), 201

@app.get("/items/<int:item_id>")
def get_item(item_id):
    return jsonify(items.get(item_id) or abort(404))

@app.errorhandler(400)
@app.errorhandler(404)
def handle_error(err):
    return jsonify(error=str(err.description)), err.code

if __name__ == "__main__":
    app.run(debug=True)
```
For production use gunicorn, blueprints for structure, and Flask-SQLAlchemy for persistence.""",

    "fastapi": """# FastAPI basics
Install: `pip install fastapi uvicorn`. Pydantic models validate request bodies automatically.

```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

class Todo(BaseModel):
    title: str
    done: bool = False

db: dict[int, Todo] = {}

@app.post("/todos/{todo_id}", status_code=201)
def create(todo_id: int, todo: Todo):
    db[todo_id] = todo
    return todo

@app.get("/todos/{todo_id}")
def read(todo_id: int):
    if todo_id not in db:
        raise HTTPException(404, "Not found")
    return db[todo_id]
```
Run with `uvicorn main:app --reload`. Interactive docs at /docs.""",

    "cnn-pytorch": """# Convolutional Neural Network (CNN) in PyTorch
A CNN for 28x28 grayscale images (MNIST-style):

```python
import torch
import torch.nn as nn
import torch.nn.functional as F

class CNN(nn.Module):
    def __init__(self, num_classes: int = 10):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2)
        self.dropout = nn.Dropout(0.25)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, num_classes)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))   # 28 -> 14
        x = self.pool(F.relu(self.conv2(x)))   # 14 -> 7
        x = self.dropout(x.flatten(1))
        x = F.relu(self.fc1(x))
        return self.fc2(x)

model = CNN()
opt = torch.optim.Adam(model.parameters(), lr=1e-3)
loss_fn = nn.CrossEntropyLoss()

def train_epoch(loader, device="cpu"):
    model.train()
    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        opt.zero_grad()
        loss = loss_fn(model(xb), yb)
        loss.backward()
        opt.step()
```
Load data with `torchvision.datasets.MNIST` and `DataLoader(batch_size=64, shuffle=True)`.""",

    "cnn-keras": """# CNN in Keras / TensorFlow
```python
from tensorflow import keras
from tensorflow.keras import layers

model = keras.Sequential([
    layers.Input(shape=(28, 28, 1)),
    layers.Conv2D(32, 3, activation="relu"),
    layers.MaxPooling2D(),
    layers.Conv2D(64, 3, activation="relu"),
    layers.MaxPooling2D(),
    layers.Flatten(),
    layers.Dropout(0.5),
    layers.Dense(10, activation="softmax"),
])
model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()
x_train = x_train[..., None] / 255.0
model.fit(x_train, y_train, epochs=3, batch_size=128, validation_split=0.1)
```""",

    "python-files-errors": """# File handling and error handling in Python
Always use context managers and catch specific exceptions.

```python
from pathlib import Path
import json

def read_json(path: str) -> dict:
    try:
        with Path(path).open(encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        raise SystemExit(f"File not found: {path}")
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in {path}: {e}") from e
```
Use `try/except/else/finally`, custom exception classes for domain errors, and the `logging` module instead of print in libraries.""",

    "python-requests": """# HTTP requests with `requests`
```python
import requests

def fetch_json(url: str, timeout: float = 10.0) -> dict:
    try:
        resp = requests.get(url, timeout=timeout, headers={"Accept": "application/json"})
        resp.raise_for_status()
        return resp.json()
    except requests.Timeout:
        raise RuntimeError("Request timed out")
    except requests.HTTPError as e:
        raise RuntimeError(f"HTTP {e.response.status_code}") from e
```
Always set a timeout; reuse a `requests.Session()` for many calls; retry with `urllib3.util.Retry`.""",

    "pandas-basics": """# pandas data analysis recipes
```python
import pandas as pd

df = pd.read_csv("data.csv")
df = df.dropna(subset=["price"]).assign(price=lambda d: d["price"].astype(float))
summary = df.groupby("category")["price"].agg(["count", "mean", "max"]).sort_values("mean", ascending=False)
df["date"] = pd.to_datetime(df["date"])
monthly = df.set_index("date").resample("MS")["price"].sum()
print(summary.head())
```
Prefer vectorised operations over loops; use `.loc` for assignment to avoid SettingWithCopyWarning.""",

    "python-decorators-async": """# Decorators and asyncio
```python
import functools, time, asyncio

def timer(fn):
    @functools.wraps(fn)
    def wrapper(*a, **kw):
        t = time.perf_counter()
        try:
            return fn(*a, **kw)
        finally:
            print(f"{fn.__name__} took {time.perf_counter() - t:.4f}s")
    return wrapper

async def fetch(i):
    await asyncio.sleep(0.1)
    return i * 2

async def main():
    results = await asyncio.gather(*(fetch(i) for i in range(5)))
    print(results)

asyncio.run(main())
```""",

    "python-sqlite": """# SQLite with the standard library
```python
import sqlite3

conn = sqlite3.connect("app.db")
conn.execute("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL)")
with conn:  # commits or rolls back automatically
    conn.execute("INSERT INTO users(name) VALUES (?)", ("Ada",))
for row in conn.execute("SELECT id, name FROM users"):
    print(row)
conn.close()
```
Always use parameter placeholders (`?`) - never f-strings - to prevent SQL injection.""",

    "python-unittest-pytest": """# Testing with pytest
```python
import pytest

def divide(a, b):
    if b == 0:
        raise ZeroDivisionError("b must not be zero")
    return a / b

@pytest.mark.parametrize("a,b,expected", [(6, 3, 2), (1, 4, 0.25)])
def test_divide(a, b, expected):
    assert divide(a, b) == expected

def test_divide_by_zero():
    with pytest.raises(ZeroDivisionError):
        divide(1, 0)
```
Run with `pytest -q`. Use fixtures for shared setup and `tmp_path` for temporary files.""",

    "python-cli-argparse": """# Command line tools with argparse
```python
import argparse

def main():
    p = argparse.ArgumentParser(description="Word counter")
    p.add_argument("path")
    p.add_argument("--top", type=int, default=5)
    args = p.parse_args()
    from collections import Counter
    words = open(args.path, encoding="utf-8").read().lower().split()
    for w, c in Counter(words).most_common(args.top):
        print(f"{w}: {c}")

if __name__ == "__main__":
    main()
```""",
}


def seed(kb: KnowledgeBase, folder: str | None = None) -> int:
    total = 0
    for name, text in DOCS.items():
        total += kb.add_document(text, source=name, extra_metadata={"type": "seed", "topic": name})
    if folder:
        for p in Path(folder).rglob("*"):
            if p.suffix.lower() in {".md", ".txt", ".py"} and p.is_file():
                total += kb.add_document(p.read_text(encoding="utf-8", errors="replace"), source=p.name, extra_metadata={"type": "folder_import"})
    return total


if __name__ == "__main__":
    kb = KnowledgeBase()
    n = seed(kb, sys.argv[1] if len(sys.argv) > 1 else None)
    print(f"Stored {n} chunks. Collection now holds {kb.count()} chunks.")
