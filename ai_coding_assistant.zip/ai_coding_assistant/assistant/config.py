"""Central configuration, overridable through environment variables / .env."""
import os
from pathlib import Path

try:  # optional dependency
    from dotenv import load_dotenv

    load_dotenv()
except Exception:  # pragma: no cover
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("ASSISTANT_DATA_DIR", BASE_DIR / "data"))
CHROMA_DIR = Path(os.getenv("CHROMA_DIR", DATA_DIR / "chroma"))
MEMORY_FILE = Path(os.getenv("MEMORY_FILE", DATA_DIR / "memory.json"))

# --- LLM (any OpenAI-compatible endpoint: OpenAI, Groq, Together, Ollama, ...) ---
LLM_API_KEY = os.getenv("LLM_API_KEY") or os.getenv("OPENAI_API_KEY", "")
LLM_BASE_URL = os.getenv("LLM_BASE_URL") or None
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")

# --- RAG ---
COLLECTION_NAME = os.getenv("CHROMA_COLLECTION", "coding_knowledge")
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", 800))       # characters
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", 120))  # characters
TOP_K = int(os.getenv("TOP_K", 4))

# --- Memory ---
SHORT_TERM_TURNS = int(os.getenv("SHORT_TERM_TURNS", 8))

# --- Code runner ---
RUN_TIMEOUT_SECONDS = int(os.getenv("RUN_TIMEOUT_SECONDS", 10))
RUN_MAX_OUTPUT_CHARS = int(os.getenv("RUN_MAX_OUTPUT_CHARS", 10000))
RUN_MEMORY_MB = int(os.getenv("RUN_MEMORY_MB", 512))
