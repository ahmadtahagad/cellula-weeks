"""Thin wrapper around an OpenAI-compatible chat API (supports streaming)."""
from __future__ import annotations

from typing import Iterator, List, Dict, Optional

from . import config

Message = Dict[str, str]


class LLM:
    def __init__(
        self,
        model: Optional[str] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        from openai import OpenAI

        self.model = model or config.LLM_MODEL
        key = api_key or config.LLM_API_KEY
        if not key and not (base_url or config.LLM_BASE_URL):
            raise RuntimeError(
                "No LLM API key found. Set LLM_API_KEY (or OPENAI_API_KEY) in your "
                "environment / .env file, or enter it in the Streamlit sidebar."
            )
        self.client = OpenAI(
            api_key=key or "not-needed",  # local servers (Ollama) ignore the key
            base_url=base_url or config.LLM_BASE_URL,
        )

    def chat(self, messages: List[Message], temperature: float = 0.0, max_tokens: int = 2000) -> str:
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return (resp.choices[0].message.content or "").strip()

    def stream(self, messages: List[Message], temperature: float = 0.2, max_tokens: int = 3000) -> Iterator[str]:
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=True,
        )
        for chunk in resp:
            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta.content
            if delta:
                yield delta
