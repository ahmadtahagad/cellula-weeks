"""RAG layer: chunking, embeddings, Chroma persistence, top-k similarity search."""
from __future__ import annotations

import hashlib
import re
import time
from dataclasses import dataclass
from typing import List, Optional

from . import config


@dataclass
class RetrievedDoc:
    text: str
    source: str
    metadata: dict
    distance: float


def chunk_text(text: str, chunk_size: int = config.CHUNK_SIZE, overlap: int = config.CHUNK_OVERLAP) -> List[str]:
    """Paragraph-aware chunking with character overlap.

    Fenced code blocks are kept intact when they fit, so a snippet is not cut in half.
    """
    text = text.strip()
    if not text:
        return []
    if len(text) <= chunk_size:
        return [text]

    # split into paragraphs, but never inside a ``` fence
    parts, buf, in_fence = [], [], False
    for line in text.splitlines():
        if line.strip().startswith("```"):
            in_fence = not in_fence
        buf.append(line)
        if not in_fence and not line.strip():
            parts.append("\n".join(buf).strip())
            buf = []
    if buf:
        parts.append("\n".join(buf).strip())
    parts = [p for p in parts if p]

    chunks, current = [], ""
    for p in parts:
        if len(p) > chunk_size:  # oversized block: hard-split with overlap
            if current:
                chunks.append(current)
                current = ""
            step = max(1, chunk_size - overlap)
            for i in range(0, len(p), step):
                chunks.append(p[i:i + chunk_size])
            continue
        if len(current) + len(p) + 2 <= chunk_size:
            current = f"{current}\n\n{p}" if current else p
        else:
            chunks.append(current)
            tail = current[-overlap:] if overlap else ""
            current = f"{tail}\n\n{p}" if tail else p
    if current:
        chunks.append(current)
    return [c.strip() for c in chunks if c.strip()]


class KnowledgeBase:
    """Chroma-backed vector store holding documents, embeddings, metadata and sources."""

    def __init__(self, persist_dir=None, collection_name: str = config.COLLECTION_NAME, embedding_function=None):
        import chromadb

        persist_dir = str(persist_dir or config.CHROMA_DIR)
        self.client = chromadb.PersistentClient(path=persist_dir)
        if embedding_function is None:
            from chromadb.utils import embedding_functions

            embedding_function = embedding_functions.DefaultEmbeddingFunction()  # local MiniLM, no API key
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            embedding_function=embedding_function,
            metadata={"hnsw:space": "cosine"},
        )

    # ---------- write ----------
    def add_document(self, text: str, source: str = "manual", extra_metadata: Optional[dict] = None) -> int:
        """Chunk -> embed (Chroma does this via the embedding function) -> store. Returns #chunks."""
        chunks = chunk_text(text)
        if not chunks:
            return 0
        doc_id = hashlib.sha1(text.encode("utf-8")).hexdigest()[:16]
        now = time.strftime("%Y-%m-%dT%H:%M:%S")
        ids, metas = [], []
        for i, _ in enumerate(chunks):
            ids.append(f"{doc_id}-{i}")
            md = {"source": source, "doc_id": doc_id, "chunk_index": i, "n_chunks": len(chunks), "added_at": now}
            md.update(extra_metadata or {})
            metas.append({k: (v if isinstance(v, (str, int, float, bool)) else str(v)) for k, v in md.items()})
        self.collection.upsert(ids=ids, documents=chunks, metadatas=metas)  # upsert => idempotent
        return len(chunks)

    def learn_from_user(self, question: str, solution: str) -> int:
        """Human-feedback learning: store a user-supplied solution with metadata."""
        doc = f"Question / task: {question}\n\nSolution:\n{solution}"
        return self.add_document(doc, source="user_feedback", extra_metadata={"type": "user_solution", "question": question[:300]})

    # ---------- read ----------
    def search(self, query: str, k: int = config.TOP_K) -> List[RetrievedDoc]:
        n = self.collection.count()
        if n == 0:
            return []
        res = self.collection.query(query_texts=[query], n_results=min(k, n))
        out = []
        for doc, meta, dist in zip(res["documents"][0], res["metadatas"][0], res["distances"][0]):
            out.append(RetrievedDoc(text=doc, source=(meta or {}).get("source", "unknown"), metadata=meta or {}, distance=float(dist)))
        return out

    def count(self) -> int:
        return self.collection.count()


def format_context(docs: List[RetrievedDoc]) -> str:
    return "\n\n".join(f"[{i + 1}] (source: {d.source})\n{d.text}" for i, d in enumerate(docs))


_CODE_FENCE = re.compile(r"```[a-zA-Z0-9_+-]*\n(.*?)```", re.S)


def looks_like_solution(text: str) -> bool:
    """Heuristic: does a user message contain a code solution worth learning?"""
    if _CODE_FENCE.search(text):
        return True
    codey = sum(text.count(t) for t in ("def ", "class ", "import ", "return ", "{", "};", "=>", "():"))
    return codey >= 3 and "\n" in text
