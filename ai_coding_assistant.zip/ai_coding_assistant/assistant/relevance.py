"""Second LLM acting as a Relevance Evaluator for retrieved context."""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

from .rag import RetrievedDoc, format_context

SYSTEM_PROMPT = """You are a strict Relevance Evaluator in a RAG pipeline.
You receive a user's programming request and retrieved context.
Answer this question: "Is the retrieved context sufficiently relevant to answer the user's request?"

- RELEVANT      : the context contains information (APIs, patterns, examples, concepts)
                  that directly helps fulfil the request.
- NOT_RELEVANT  : the context is off-topic, only superficially similar, or too thin to help.

Reply with exactly one word: RELEVANT or NOT_RELEVANT."""


@dataclass
class RelevanceVerdict:
    relevant: bool
    raw: str


class RelevanceEvaluator:
    def __init__(self, llm):
        self.llm = llm

    def evaluate(self, query: str, docs: List[RetrievedDoc]) -> RelevanceVerdict:
        if not docs:
            return RelevanceVerdict(False, "no documents retrieved")
        user = f"User request:\n{query}\n\nRetrieved context:\n{format_context(docs)}"
        raw = self.llm.chat(
            [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": user}],
            temperature=0.0,
            max_tokens=6,
        )
        text = raw.strip().upper().replace(" ", "_")
        # NOT_RELEVANT must be checked first because it contains "RELEVANT"
        if text.startswith("NOT") or "NOT_RELEVANT" in text:
            return RelevanceVerdict(False, raw)
        return RelevanceVerdict(text.startswith("RELEVANT"), raw)
