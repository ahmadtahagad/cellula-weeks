"""Code Runner Tool.

Receives source code as a string, executes it in a controlled subprocess, captures
stdout / stderr and returns the result. The LLM never executes code itself.

Controls: isolated temp dir, `python -I` (isolated mode), scrubbed environment,
wall-clock timeout, CPU/memory/file-size limits (POSIX), truncated output.

NOTE: this is process-level isolation, not a full sandbox. For untrusted
multi-user deployments run it inside a container/VM.
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, asdict

from . import config


@dataclass
class ExecutionResult:
    stdout: str
    stderr: str
    returncode: int
    timed_out: bool
    duration_s: float

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and not self.timed_out

    def to_dict(self) -> dict:
        d = asdict(self)
        d["ok"] = self.ok
        return d


def _limit_resources():  # pragma: no cover - runs in the child process
    try:
        import resource

        mem = config.RUN_MEMORY_MB * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_AS, (mem, mem))
        resource.setrlimit(resource.RLIMIT_CPU, (config.RUN_TIMEOUT_SECONDS + 1, config.RUN_TIMEOUT_SECONDS + 1))
        resource.setrlimit(resource.RLIMIT_FSIZE, (10 * 1024 * 1024, 10 * 1024 * 1024))
    except Exception:
        pass


def _clip(text: str) -> str:
    limit = config.RUN_MAX_OUTPUT_CHARS
    return text if len(text) <= limit else text[:limit] + f"\n... [truncated {len(text) - limit} chars]"


def run_python(code: str, timeout: int | None = None, stdin: str = "") -> ExecutionResult:
    timeout = timeout or config.RUN_TIMEOUT_SECONDS
    env = {"PATH": os.environ.get("PATH", ""), "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1"}
    with tempfile.TemporaryDirectory(prefix="runner_") as tmp:
        script = os.path.join(tmp, "snippet.py")
        with open(script, "w", encoding="utf-8") as f:
            f.write(code)
        start = time.time()
        try:
            proc = subprocess.run(
                [sys.executable, "-I", script],
                input=stdin,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=tmp,
                env=env,
                preexec_fn=_limit_resources if os.name == "posix" else None,
            )
            return ExecutionResult(_clip(proc.stdout), _clip(proc.stderr), proc.returncode, False, time.time() - start)
        except subprocess.TimeoutExpired as e:
            out = e.stdout.decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
            err = e.stderr.decode() if isinstance(e.stderr, bytes) else (e.stderr or "")
            return ExecutionResult(_clip(out), _clip(err) + f"\nExecution timed out after {timeout}s.", -1, True, time.time() - start)
        except Exception as e:  # pragma: no cover
            return ExecutionResult("", f"Runner error: {e}", -1, False, time.time() - start)


def run_code(code: str, language: str = "python", **kw) -> ExecutionResult:
    """Tool entry point invoked by the assistant/UI."""
    if language.lower() not in ("python", "py", "python3"):
        return ExecutionResult("", f"Language '{language}' is not supported by the runner (Python only).", 1, False, 0.0)
    return run_python(code, **kw)
