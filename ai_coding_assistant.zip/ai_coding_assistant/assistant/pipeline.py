"""Orchestration: classifier -> router -> (explain | RAG + relevance + generate) -> feedback learning."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterator, List, Optional, Tuple

from . import config
from .classifier import EXPLAIN, GENERATE, IntentClassifier
from .memory import ConversationMemory
from .rag import KnowledgeBase, RetrievedDoc, format_context, looks_like_solution
from .relevance import RelevanceEvaluator, RelevanceVerdict

NO_KNOWLEDGE_MESSAGE = (
    "I couldn't find relevant knowledge for your request. Could you provide the correct "
    "solution or reference so I can learn it for future interactions?"
)

EXPLAIN_SYSTEM = """You are an expert programming tutor. The user wants existing code explained, reviewed or debugged.
Analyse ONLY the code the user provided and answer directly.
- Give a short summary first, then a clear walk-through (line by line if asked).
- Point out bugs, edge cases and improvements where relevant.
- Use Markdown; put any code in fenced blocks with a language tag.
- If no code was provided, ask the user to paste it."""

GENERATE_SYSTEM = """You are an expert software engineer. Write production-quality code for the user's request,
using the retrieved knowledge below as your primary reference. Do not invent APIs that contradict it.

Your answer MUST contain:
1. Complete, runnable source code in a single fenced Markdown block with a language tag.
2. Helpful comments and docstrings.
3. Best practices (type hints, clear naming, small functions).
4. Proper error handling.
5. A brief explanation after the code (2-5 sentences).
If the user has stated a language/framework preference, follow it. For Python, prefer scripts that
run standalone and print a small demo so the output can be verified.

Retrieved knowledge:
{context}"""

_PREF_TRIGGER = re.compile(
    r"\b(prefer|always|i use|i work|i like|please use|from now on|my stack|"
    r"in (python|java|javascript|typescript|c\+\+|c#|go|rust|kotlin|php|ruby))\b",
    re.I,
)
_FENCE = re.compile(r"```([a-zA-Z0-9_+#-]*)\n(.*?)```", re.S)


def extract_code_blocks(text: str) -> List[Tuple[str, str]]:
    """Return [(language, code), ...] for every fenced block in `text`."""
    return [(lang.lower() or "text", code.strip("\n")) for lang, code in _FENCE.findall(text)]


@dataclass
class PipelineResult:
    route: str                                   # explain | generate | learn | no_knowledge
    stream: Iterator[str]                        # consume this to get the answer text
    intent: str = ""
    retrieved: List[RetrievedDoc] = field(default_factory=list)
    relevance: Optional[RelevanceVerdict] = None


def _once(text: str) -> Iterator[str]:
    yield text


class AssistantPipeline:
    def __init__(
        self,
        llm,
        kb: KnowledgeBase,
        memory: Optional[ConversationMemory] = None,
        classifier: Optional[IntentClassifier] = None,
        evaluator: Optional[RelevanceEvaluator] = None,
    ):
        self.llm = llm
        self.kb = kb
        self.memory = memory or ConversationMemory()
        self.classifier = classifier or IntentClassifier(llm)
        self.evaluator = evaluator or RelevanceEvaluator(llm)
        self.pending_question: Optional[str] = None   # set when retrieval failed -> next code msg is learned

    # ------------------------------------------------------------------ public
    def handle(self, query: str, uploaded_text: Optional[str] = None) -> PipelineResult:
        full_query = query if not uploaded_text else f"{query}\n\n[Attached file]\n```\n{uploaded_text}\n```"

        # 7. Human feedback learning: user answers our "please teach me" request
        if self.pending_question and looks_like_solution(query):
            question, self.pending_question = self.pending_question, None
            n = self.kb.learn_from_user(question, query)
            msg = (
                f"Thank you! I stored your solution ({n} chunk{'s' if n != 1 else ''}) in my knowledge base "
                f"with embeddings and metadata. Ask me again and I'll use it."
            )
            self.memory.add_user(query)
            return PipelineResult("learn", self._finish(_once(msg)))
        self.pending_question = None  # user moved on to something else

        # 2. classify (sees recent turns so follow-ups work)
        intent = self.classifier.classify(full_query, self.memory.recent_text())
        self.memory.add_user(query)
        if _PREF_TRIGGER.search(query):
            self.memory.update_preferences(self.llm, query)

        # 3. route
        if intent == EXPLAIN:
            return self._explain(full_query)
        return self._generate(query, full_query)

    # ------------------------------------------------------------------ routes
    def _explain(self, full_query: str) -> PipelineResult:
        """Route 1: NO RAG, NO vector search, NO embeddings. LLM analyses the code directly."""
        messages = self._messages(EXPLAIN_SYSTEM, full_query)
        return PipelineResult(EXPLAIN, self._finish(self.llm.stream(messages)), intent=EXPLAIN)

    def _generate(self, query: str, full_query: str) -> PipelineResult:
        """Route 2: RAG retrieval -> relevance check -> (LLM generation | ask user to teach)."""
        docs = self.kb.search(query, k=config.TOP_K)
        verdict = self.evaluator.evaluate(query, docs)
        if not verdict.relevant:
            self.pending_question = query  # remember what to attach the user's solution to
            return PipelineResult("no_knowledge", self._finish(_once(NO_KNOWLEDGE_MESSAGE)), intent=GENERATE, retrieved=docs, relevance=verdict)
        system = GENERATE_SYSTEM.format(context=format_context(docs))
        messages = self._messages(system, full_query)
        return PipelineResult(GENERATE, self._finish(self.llm.stream(messages)), intent=GENERATE, retrieved=docs, relevance=verdict)

    # ------------------------------------------------------------------ helpers
    def _messages(self, system: str, user_content: str) -> list:
        profile = self.memory.profile_text()
        sys_msg = system + (f"\n\nMemory about this user:\n{profile}" if profile else "")
        history = self.memory.history_messages(exclude_last_user=True)
        return [{"role": "system", "content": sys_msg}, *history, {"role": "user", "content": user_content}]

    def _finish(self, stream: Iterator[str]) -> Iterator[str]:
        """Yield tokens, then commit the full answer to memory when the stream is exhausted."""
        parts: List[str] = []
        for tok in stream:
            parts.append(tok)
            yield tok
        full = "".join(parts)
        blocks = extract_code_blocks(full)
        self.memory.add_assistant(full, code=blocks[-1][1] if blocks else None)
