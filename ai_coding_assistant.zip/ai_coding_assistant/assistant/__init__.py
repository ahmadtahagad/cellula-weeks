"""Intelligent AI Coding Assistant package."""
from .pipeline import AssistantPipeline, PipelineResult

__all__ = ["AssistantPipeline", "PipelineResult"]
