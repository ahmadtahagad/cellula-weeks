"""Conversation memory: short-term turns + persistent long-term profile."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Optional

from . import config

EXTRACT_PROMPT = """Extract stable user preferences from the message below.
Return ONLY a JSON object with these optional keys (omit unknown ones):
  "language"   - preferred programming language
  "framework"  - preferred framework/library
  "style"      - coding style or response preferences (short phrase)
If nothing is stated, return {}.

Message:
"""


class ConversationMemory:
    def __init__(self, path: Optional[Path] = None, max_turns: int = config.SHORT_TERM_TURNS):
        self.path = Path(path or config.MEMORY_FILE)
        self.max_turns = max_turns
        self.turns: List[Dict[str, str]] = []      # short-term: {"role", "content"}
        self.preferences: Dict[str, str] = {}      # long-term: language / framework / style
        self.past_questions: List[str] = []        # long-term: previous questions
        self.generated_code: List[Dict[str, str]] = []  # long-term: previous code
        self._load()

    # ---------- persistence ----------
    def _load(self) -> None:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.preferences = data.get("preferences", {})
            self.past_questions = data.get("past_questions", [])
            self.generated_code = data.get("generated_code", [])
        except Exception:
            pass

    def _save(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(
                json.dumps(
                    {
                        "preferences": self.preferences,
                        "past_questions": self.past_questions[-50:],
                        "generated_code": self.generated_code[-20:],
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
        except Exception:
            pass

    # ---------- updates ----------
    def add_user(self, text: str) -> None:
        self.turns.append({"role": "user", "content": text})
        self.past_questions.append(text[:300])
        self._trim()
        self._save()

    def add_assistant(self, text: str, code: Optional[str] = None) -> None:
        self.turns.append({"role": "assistant", "content": text})
        if code:
            self.generated_code.append({"question": self.past_questions[-1] if self.past_questions else "", "code": code[:4000]})
        self._trim()
        self._save()

    def _trim(self) -> None:
        self.turns = self.turns[-2 * self.max_turns:]

    def update_preferences(self, llm, message: str) -> None:
        """Ask the LLM to pull out language/framework preferences (best effort)."""
        try:
            raw = llm.chat([{"role": "user", "content": EXTRACT_PROMPT + message}], temperature=0.0, max_tokens=150)
            start, end = raw.find("{"), raw.rfind("}")
            found = json.loads(raw[start:end + 1]) if start != -1 else {}
            for k in ("language", "framework", "style"):
                if found.get(k):
                    self.preferences[k] = str(found[k])
            self._save()
        except Exception:
            pass

    def clear(self) -> None:
        self.turns, self.preferences, self.past_questions, self.generated_code = [], {}, [], []
        self._save()

    # ---------- views ----------
    def history_messages(self, exclude_last_user: bool = False) -> List[Dict[str, str]]:
        turns = self.turns[:-1] if exclude_last_user and self.turns and self.turns[-1]["role"] == "user" else self.turns
        return list(turns)

    def profile_text(self) -> str:
        parts = []
        if self.preferences:
            parts.append("User preferences: " + ", ".join(f"{k}={v}" for k, v in self.preferences.items()))
        if self.generated_code:
            last = self.generated_code[-1]
            parts.append(f"Most recent code you generated (for follow-ups):\n{last['code'][:1500]}")
        return "\n".join(parts)

    def recent_text(self, n: int = 4) -> str:
        return "\n".join(f"{t['role']}: {t['content'][:300]}" for t in self.turns[-n:])

    def snapshot(self) -> dict:
        return {
            "preferences": self.preferences,
            "short_term_turns": len(self.turns),
            "past_questions": self.past_questions[-10:],
            "generated_code_items": len(self.generated_code),
        }
