"""LLM-based intent classifier: EXPLAIN vs GENERATE."""
from __future__ import annotations

import re

EXPLAIN = "explain"
GENERATE = "generate"

SYSTEM_PROMPT = """You are an intent classifier for a coding assistant.
Classify the user's latest request into exactly ONE class:

EXPLAIN  - the user wants existing code explained, understood, reviewed or debugged.
           Examples: "Explain this code", "What does this function do?",
           "Why is this loop incorrect?", "Explain line by line".
GENERATE - the user wants NEW code written.
           Examples: "Write Python code ...", "Generate a CNN model",
           "Build a Flask API", "Create a sorting algorithm".

Rules:
- If the message contains pasted code AND asks what/why/how it works -> EXPLAIN.
- If the user asks for something to be built, written, created or generated -> GENERATE.
- Use the recent conversation only to resolve follow-ups like "now make it async".
Reply with ONE word only: EXPLAIN or GENERATE."""

_EXPLAIN_HINTS = re.compile(
    r"\b(explain|what does|what is this|why (is|does|doesn't|isn't)|line by line|"
    r"walk me through|how does this|understand this|what's wrong|debug)\b",
    re.I,
)


def _heuristic(query: str) -> str:
    """Fallback used only if the LLM reply cannot be parsed."""
    return EXPLAIN if _EXPLAIN_HINTS.search(query) else GENERATE


class IntentClassifier:
    def __init__(self, llm):
        self.llm = llm

    def classify(self, query: str, recent_context: str = "") -> str:
        user = f"Recent conversation (may be empty):\n{recent_context}\n\nLatest request:\n{query}"
        try:
            raw = self.llm.chat(
                [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": user}],
                temperature=0.0,
                max_tokens=5,
            )
        except Exception:
            return _heuristic(query)
        text = raw.strip().upper()
        if text.startswith("EXPLAIN"):
            return EXPLAIN
        if text.startswith("GENERATE"):
            return GENERATE
        return _heuristic(query)
