"""Offline tests: fake LLM + fake embeddings, so no API key or model download is needed."""
import hashlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

from assistant.classifier import EXPLAIN, GENERATE, IntentClassifier
from assistant.code_runner import run_code
from assistant.memory import ConversationMemory
from assistant.pipeline import AssistantPipeline, NO_KNOWLEDGE_MESSAGE, extract_code_blocks
from assistant.rag import KnowledgeBase, chunk_text, looks_like_solution


class FakeEmbedding:
    """Deterministic bag-of-words hashing embedding (similar words -> similar vectors)."""
    def __init__(self, dim=64):
        self.dim = dim

    def name(self):
        return "fake-hash-embedding"

    def __call__(self, input):
        out = []
        for text in input:
            v = [0.0] * self.dim
            for w in text.lower().split():
                v[int(hashlib.md5(w.encode()).hexdigest(), 16) % self.dim] += 1.0
            out.append(v)
        return out

    def embed_query(self, input):
        return self(input)


class FakeLLM:
    """Rule-based stand-in. Records every call so tests can assert on routing."""
    def __init__(self, relevant=True):
        self.relevant = relevant
        self.calls = []

    def chat(self, messages, **kw):
        sys_prompt = messages[0]["content"]
        self.calls.append("chat:" + sys_prompt[:20])
        if "intent classifier" in sys_prompt:
            last = messages[-1]["content"].lower()
            return "EXPLAIN" if ("explain" in last or "what does" in last) else "GENERATE"
        if "Relevance Evaluator" in sys_prompt:
            return "RELEVANT" if self.relevant else "NOT_RELEVANT"
        return "{}"

    def stream(self, messages, **kw):
        self.calls.append("stream")
        yield "Here you go:\n```python\nprint('hi')\n```\n"


@pytest.fixture
def kb(tmp_path):
    k = KnowledgeBase(persist_dir=tmp_path / "chroma", embedding_function=FakeEmbedding())
    k.add_document("Flask REST API example with jsonify and request routes", source="flask")
    return k


def make_pipeline(kb, tmp_path, relevant=True):
    llm = FakeLLM(relevant)
    return AssistantPipeline(llm, kb, ConversationMemory(tmp_path / "mem.json")), llm


def test_classifier():
    c = IntentClassifier(FakeLLM())
    assert c.classify("Explain this code") == EXPLAIN
    assert c.classify("Build a Flask API") == GENERATE


def test_explain_route_never_touches_rag(kb, tmp_path, monkeypatch):
    p, llm = make_pipeline(kb, tmp_path)
    monkeypatch.setattr(kb, "search", lambda *a, **k: pytest.fail("RAG must not run on explain route"))
    res = p.handle("Explain this code: def f(): pass")
    assert res.route == "explain" and res.retrieved == []
    "".join(res.stream)
    assert not any("Relevance" in c for c in llm.calls)


def test_generate_route_relevant(kb, tmp_path):
    p, _ = make_pipeline(kb, tmp_path)
    res = p.handle("Build a Flask API")
    out = "".join(res.stream)
    assert res.route == "generate" and res.retrieved and "print" in out


def test_not_relevant_then_learning(kb, tmp_path):
    p, _ = make_pipeline(kb, tmp_path, relevant=False)
    res = p.handle("Write a quantum annealing optimizer")
    assert res.route == "no_knowledge"
    assert "".join(res.stream) == NO_KNOWLEDGE_MESSAGE
    before = kb.count()
    solution = "Here is the correct implementation:\n```python\ndef anneal():\n    return 1\n```"
    res2 = p.handle(solution)
    "".join(res2.stream)
    assert res2.route == "learn" and kb.count() > before
    hits = kb.search("quantum annealing optimizer", k=1)
    assert hits[0].source == "user_feedback"


def test_memory_roundtrip(kb, tmp_path):
    p, _ = make_pipeline(kb, tmp_path)
    "".join(p.handle("Build a Flask API").stream)
    mem2 = ConversationMemory(tmp_path / "mem.json")
    assert mem2.past_questions and mem2.generated_code


def test_chunking_keeps_code_blocks():
    text = "intro\n\n```python\n" + "x = 1\n" * 30 + "```\n\n" + "para " * 200
    chunks = chunk_text(text, chunk_size=400, overlap=40)
    assert len(chunks) > 1 and all(len(c) <= 460 for c in chunks)


def test_helpers():
    assert extract_code_blocks("a\n```python\nx=1\n```")[0] == ("python", "x=1")
    assert looks_like_solution("```py\nx\n```") and not looks_like_solution("thanks")


def test_runner_success_error_timeout():
    ok = run_code("print(2+2)")
    assert ok.ok and ok.stdout.strip() == "4"
    bad = run_code("raise ValueError('boom')")
    assert not bad.ok and "ValueError" in bad.stderr
    slow = run_code("while True: pass", timeout=1)
    assert slow.timed_out
